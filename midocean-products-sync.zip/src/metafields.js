const shopifyRest = require('./shopifyClient').shopifyRest;
const logger = require('./logger');

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function extractIdFromGid(gid) {
  if (!gid) return null;
  const parts = gid.toString().split('/');
  return parts[parts.length - 1];
}

/**
 * Builds all product metafields from productData
 * Returns array of metafield objects ready for API calls
 */
function buildProductMetafields(productData, nonImageAssets = []) {
  const metafields = [];

  // Helper to add metafield if value exists
  const addMetafield = (key, value, type, validator = null) => {
    if (value !== undefined && value !== null && value !== '') {
      let processedValue = value;
      
      // Apply validator if provided
      if (validator) {
        const validationResult = validator(value);
        if (!validationResult.valid) {
          logger.debug(`Skipping invalid ${key} metafield`, {
            key,
            value,
            reason: validationResult.reason,
            master_code: productData.master_code
          });
          return;
        }
        processedValue = validationResult.value;
      }
      
      metafields.push({
        namespace: 'midocean',
        key,
        value: processedValue.toString(),
        type
      });
    }
  };

  // Text fields
  addMetafield('master_code', productData.master_code, 'single_line_text_field');
  addMetafield('product_name', productData.product_name, 'single_line_text_field');
  addMetafield('printable', productData.printable?.toString(), 'single_line_text_field');
  addMetafield('type_of_products', productData.type_of_products, 'single_line_text_field');
  addMetafield('commodity_code', productData.commodity_code, 'single_line_text_field');
  addMetafield('category_code', productData.category_code, 'single_line_text_field');
  addMetafield('country_of_origin', productData.country_of_origin, 'single_line_text_field');
  addMetafield('dimensions', productData.dimensions, 'single_line_text_field');
  addMetafield('length_unit', productData.length_unit, 'single_line_text_field');
  addMetafield('width_unit', productData.width_unit, 'single_line_text_field');
  addMetafield('height_unit', productData.height_unit, 'single_line_text_field');
  addMetafield('volume_unit', productData.volume_unit, 'single_line_text_field');
  addMetafield('carton_length_unit', productData.carton_length_unit, 'single_line_text_field');
  addMetafield('carton_width_unit', productData.carton_width_unit, 'single_line_text_field');
  addMetafield('carton_height_unit', productData.carton_height_unit, 'single_line_text_field');
  addMetafield('carton_volume_unit', productData.carton_volume_unit, 'single_line_text_field');
  addMetafield('carton_gross_weight_unit', productData.carton_gross_weight_unit, 'single_line_text_field');
  addMetafield('material', productData.material, 'single_line_text_field');
  addMetafield('packaging_after_printing', productData.packaging_after_printing, 'single_line_text_field');

  // Integer fields
  addMetafield('master_id', productData.master_id, 'number_integer', (val) => {
    const parsed = parseInt(val, 10);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('number_of_print_positions', productData.number_of_print_positions, 'number_integer', (val) => {
    const parsed = parseInt(val, 10);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('inner_carton_quantity', productData.inner_carton_quantity, 'number_integer', (val) => {
    const parsed = parseInt(val, 10);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('outer_carton_quantity', productData.outer_carton_quantity, 'number_integer', (val) => {
    const parsed = parseInt(val, 10);
    return { valid: !isNaN(parsed), value: parsed };
  });

  // Decimal fields
  addMetafield('length', productData.length, 'number_decimal', (val) => {
    const parsed = parseFloat(val);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('width', productData.width, 'number_decimal', (val) => {
    const parsed = parseFloat(val);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('height', productData.height, 'number_decimal', (val) => {
    const parsed = parseFloat(val);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('volume', productData.volume, 'number_decimal', (val) => {
    const parsed = parseFloat(val);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('net_weight', productData.net_weight, 'number_decimal', (val) => {
    const parsed = parseFloat(val);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('net_weight_unit', productData.net_weight_unit, 'single_line_text_field');
  addMetafield('carton_length', productData.carton_length, 'number_decimal', (val) => {
    const parsed = parseFloat(val);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('carton_width', productData.carton_width, 'number_decimal', (val) => {
    const parsed = parseFloat(val);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('carton_height', productData.carton_height, 'number_decimal', (val) => {
    const parsed = parseFloat(val);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('carton_volume', productData.carton_volume, 'number_decimal', (val) => {
    const parsed = parseFloat(val);
    return { valid: !isNaN(parsed), value: parsed };
  });
  addMetafield('carton_gross_weight', productData.carton_gross_weight, 'number_decimal', (val) => {
    const parsed = parseFloat(val);
    return { valid: !isNaN(parsed), value: parsed };
  });

  // Date/DateTime fields
  addMetafield('timestamp', productData.timestamp, 'date_time');

  // JSON fields
  if (nonImageAssets && nonImageAssets.length > 0) {
    metafields.push({
      namespace: 'midocean',
      key: 'digital_assets',
      value: JSON.stringify(nonImageAssets),
      type: 'json'
    });
  }

  return metafields;
}

/**
 * Builds all variant metafields from variant data
 * Returns array of metafield objects ready for API calls
 */
function buildVariantMetafields(variant) {
  if (!variant || typeof variant !== 'object') {
    return [];
  }

  const metafields = [];
  
  // Debug: Log variant data to help troubleshoot
  logger.debug('Building variant metafields', {
    sku: variant.sku,
    has_discontinued_date: variant.discontinued_date !== undefined,
    discontinued_date: variant.discontinued_date,
    has_release_date: variant.release_date !== undefined,
    release_date: variant.release_date
  });

  // Helper to add metafield if value exists
  const addMetafield = (key, value, type, validator = null) => {
    if (value !== undefined && value !== null && value !== '') {
      let processedValue = value;
      
      // Apply validator if provided
      if (validator) {
        const validationResult = validator(value);
        if (!validationResult.valid) {
          return;
        }
        processedValue = validationResult.value;
      }
      
      metafields.push({
        namespace: 'midocean',
        key,
        value: processedValue.toString(),
        type
      });
    }
  };

  // Add variant_id if it exists
  addMetafield('variant_id', variant.variant_id, 'single_line_text_field');

  // Add release_date if it exists (validate date format: YYYY-MM-DD)
  addMetafield('release_date', variant.release_date, 'date', (val) => {
    if (!val || typeof val !== 'string') {
      return { valid: false };
    }
    // Validate YYYY-MM-DD format
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(val)) {
      logger.debug('Invalid release_date format, expected YYYY-MM-DD', { value: val, sku: variant.sku });
      return { valid: false };
    }
    // Validate it's a valid date
    const date = new Date(val);
    if (isNaN(date.getTime())) {
      logger.debug('Invalid release_date value', { value: val, sku: variant.sku });
      return { valid: false };
    }
    return { valid: true, value: val };
  });

  // Add discontinued_date if it exists (validate date format: YYYY-MM-DD)
  addMetafield('discontinued_date', variant.discontinued_date, 'date', (val) => {
    if (!val || typeof val !== 'string') {
      return { valid: false };
    }
    // Validate YYYY-MM-DD format
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(val)) {
      logger.debug('Invalid discontinued_date format, expected YYYY-MM-DD', { value: val, sku: variant.sku });
      return { valid: false };
    }
    // Validate it's a valid date
    const date = new Date(val);
    if (isNaN(date.getTime())) {
      logger.debug('Invalid discontinued_date value', { value: val, sku: variant.sku });
      return { valid: false };
    }
    return { valid: true, value: val };
  });

  // Add product_proposition_category if it exists
  addMetafield('product_proposition_category', variant.product_proposition_category, 'number_integer', (val) => {
    const parsed = parseInt(val, 10);
    return { valid: !isNaN(parsed), value: parsed };
  });

  // Add color_group if it exists
  addMetafield('color_group', variant.color_group, 'single_line_text_field');

  // Add plc_status if it exists
  addMetafield('plc_status', variant.plc_status, 'number_integer', (val) => {
    const parsed = parseInt(val, 10);
    return { valid: !isNaN(parsed), value: parsed };
  });

  // Add plc_status_description if it exists
  addMetafield('plc_status_description', variant.plc_status_description, 'single_line_text_field');

  // Add color_code if it exists
  addMetafield('color_code', variant.color_code, 'number_integer', (val) => {
    const parsed = parseInt(val, 10);
    return { valid: !isNaN(parsed), value: parsed };
  });

  // Add pms_color if it exists
  addMetafield('pms_color', variant.pms_color, 'single_line_text_field');

  // Add category levels if they exist
  addMetafield('category_level1', variant.category_level1, 'single_line_text_field');
  addMetafield('category_level2', variant.category_level2, 'single_line_text_field');
  addMetafield('category_level3', variant.category_level3, 'single_line_text_field');

  return metafields;
}

/**
 * Creates product metafields in batches with rate limit handling
 * @param {string} productId - Shopify product ID
 * @param {Array} metafields - Array of metafield objects
 * @param {string} masterCode - Product master code for logging
 * @param {number} batchSize - Number of metafields to process per batch (default: 5)
 * @param {number} delayBetweenBatches - Delay in ms between batches (default: 500)
 */
async function createProductMetafieldsInBatches(productId, metafields, masterCode, batchSize = 5, delayBetweenBatches = 500) {
  if (!metafields || metafields.length === 0) {
    logger.debug('No metafields to create', { productId, master_code: masterCode });
    return { success: 0, failed: 0, skipped: 0 };
  }

  // Extract numeric ID from GID if needed
  const productIdStr = productId.toString().includes('/') 
    ? extractIdFromGid(productId.toString()) 
    : productId.toString();

  const stats = { success: 0, failed: 0, skipped: 0 };
  const totalMetafields = metafields.length;
  
  logger.info('Starting bulk product metafield creation', {
    productId: productIdStr,
    master_code: masterCode,
    totalMetafields,
    batchSize,
    delayBetweenBatches
  });

  // Process metafields in batches
  for (let i = 0; i < metafields.length; i += batchSize) {
    const batch = metafields.slice(i, i + batchSize);
    const batchNumber = Math.floor(i / batchSize) + 1;
    const totalBatches = Math.ceil(totalMetafields / batchSize);
    
    logger.debug(`Processing product metafield batch ${batchNumber}/${totalBatches}`, {
      productId: productIdStr,
      master_code: masterCode,
      batchStart: i + 1,
      batchEnd: Math.min(i + batchSize, totalMetafields),
      batchSize: batch.length
    });

    // Process batch in parallel (with individual error handling)
    const batchPromises = batch.map(async (metafield) => {
      try {
        await shopifyRest('POST', `/products/${productIdStr}/metafields.json`, {
          metafield: metafield
        });
        stats.success++;
        logger.debug('Product metafield created successfully', {
          productId,
          master_code: masterCode,
          key: metafield.key,
          type: metafield.type
        });
        return { success: true, key: metafield.key };
      } catch (err) {
        stats.failed++;
        logger.warn('Failed to create product metafield', {
          productId,
          master_code: masterCode,
          key: metafield.key,
          type: metafield.type,
          error: err.message,
          status: err.response?.status,
          responseData: err.response?.data
        });
        return { success: false, key: metafield.key, error: err.message };
      }
    });

    await Promise.all(batchPromises);

    // Add delay between batches (except for the last batch)
    if (i + batchSize < metafields.length) {
      await sleep(delayBetweenBatches);
    }
  }

  logger.info('Completed bulk product metafield creation', {
    productId: productIdStr,
    master_code: masterCode,
    totalMetafields,
    success: stats.success,
    failed: stats.failed,
    successRate: `${((stats.success / totalMetafields) * 100).toFixed(1)}%`
  });

  return stats;
}

/**
 * Creates variant metafields in batches with rate limit handling
 * @param {string} variantId - Shopify variant ID
 * @param {Array} metafields - Array of metafield objects
 * @param {string} sku - Variant SKU for logging
 * @param {number} batchSize - Number of metafields to process per batch (default: 5)
 * @param {number} delayBetweenBatches - Delay in ms between batches (default: 500)
 */
async function createVariantMetafieldsInBatches(variantId, metafields, sku, batchSize = 5, delayBetweenBatches = 500) {
  if (!metafields || metafields.length === 0) {
    logger.debug('No variant metafields to create', { variantId, sku });
    return { success: 0, failed: 0, skipped: 0 };
  }

  const stats = { success: 0, failed: 0, skipped: 0 };
  const totalMetafields = metafields.length;
  
  // Ensure variantId is a string
  const variantIdStr = String(variantId);
  
  logger.debug('Starting bulk variant metafield creation', {
    variantId: variantIdStr,
    sku,
    totalMetafields,
    batchSize
  });

  // Process metafields in batches
  for (let i = 0; i < metafields.length; i += batchSize) {
    const batch = metafields.slice(i, i + batchSize);
    const batchNumber = Math.floor(i / batchSize) + 1;
    const totalBatches = Math.ceil(totalMetafields / batchSize);

    // Process batch in parallel (with individual error handling)
    const batchPromises = batch.map(async (metafield) => {
      try {
        await shopifyRest('POST', `/variants/${variantIdStr}/metafields.json`, {
          metafield: metafield
        });
        stats.success++;
        return { success: true, key: metafield.key };
      } catch (err) {
        stats.failed++;
        logger.warn('Failed to create variant metafield', {
          variantId: variantIdStr,
          sku,
          key: metafield.key,
          type: metafield.type,
          error: err.message,
          status: err.response?.status,
          responseData: err.response?.data
        });
        return { success: false, key: metafield.key, error: err.message };
      }
    });

    await Promise.all(batchPromises);

    // Add delay between batches (except for the last batch)
    if (i + batchSize < metafields.length) {
      await sleep(delayBetweenBatches);
    }
  }

  logger.debug('Completed bulk variant metafield creation', {
    variantId: variantIdStr,
    sku,
    totalMetafields,
    success: stats.success,
    failed: stats.failed
  });

  return stats;
}

module.exports = {
  buildProductMetafields,
  buildVariantMetafields,
  createProductMetafieldsInBatches,
  createVariantMetafieldsInBatches
};

