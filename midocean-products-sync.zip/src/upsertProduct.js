const { shopifyRest, shopifyGraphql } = require('./shopifyClient');
const logger = require('./logger');
const { 
  buildProductMetafields, 
  buildVariantMetafields, 
  createProductMetafieldsInBatches,
  createVariantMetafieldsInBatches 
} = require('./metafields');
const {
  METAFIELD_BATCH_SIZE,
  METAFIELD_BATCH_DELAY_MS,
  PRODUCT_CREATION_DELAY_MS,
  VARIANT_RETRY_DELAY_MS,
  GRAPHQL_PRODUCTS_LIMIT,
  GRAPHQL_VARIANTS_LIMIT,
  MAX_PRODUCT_IMAGES,
  NEW_PRODUCT_STATUS
} = require('./config');

function extractIdFromGid(gid) {
  if (!gid) return null;
  const parts = gid.split('/');
  return parts[parts.length - 1];
}

async function findProductBySku(sku) {
  if (!sku || typeof sku !== 'string') {
    logger.warn('Invalid SKU provided to findProductBySku', { sku });
    return null;
  }

  try {
    const query = `
      query getProductBySKU($query: String!) {
        products(first: 10, query: $query) {
          edges {
            node {
              id
              title
              status
              variants(first: 50) {
                edges {
                  node {
                    id
                    sku
                  }
                }
              }
            }
          }
        }
      }
    `;

    const data = await shopifyGraphql(query, {
      query: `sku:${sku}`
    });

    if (!data || !data.products) {
      logger.debug('No products data returned from GraphQL query', { sku });
      return null;
    }

    const products = data.products.edges || [];
    if (products.length > 0) {
      return products[0].node;
    }
    return null;
  } catch (err) {
    logger.error('Error finding product by SKU', {
      sku,
      error: err.message,
      stack: err.stack
    });
    throw err;
  }
}


async function getProductWithAllVariants(productId) {
  if (!productId) {
    logger.warn('Cannot get product: missing productId');
    return null;
  }

  try {
    const id = productId.includes('/') ? extractIdFromGid(productId) : productId;
    const query = `
      query getProduct($id: ID!) {
        product(id: $id) {
          id
          title
          status
          variants(first: ${GRAPHQL_VARIANTS_LIMIT}) {
            edges {
              node {
                id
                sku
                price
                barcode
              }
            }
          }
        }
      }
    `;

    const data = await shopifyGraphql(query, { id: `gid://shopify/Product/${id}` });
    
    if (!data || !data.product) {
      logger.debug('Product not found', { productId: id });
      return null;
    }

    return data.product;
  } catch (err) {
    logger.error('Error getting product with variants', {
      productId,
      error: err.message,
      stack: err.stack
    });
    return null;
  }
}

async function addVariantToProduct(productId, variantData) {
  if (!productId || !variantData) {
    logger.warn('Cannot add variant: missing productId or variantData', { productId, variantData });
    return null;
  }

  try {
    const id = productId.includes('/') ? extractIdFromGid(productId) : productId;
    const response = await shopifyRest('POST', `/products/${id}/variants.json`, {
      variant: variantData
    });

    if (response && response.variant) {
      logger.info('Variant added successfully', {
        productId: id,
        variantId: response.variant.id,
        sku: variantData.sku
      });
      
      // Add variant metafields if they exist
      // Note: variantData may contain variant_id, but we need the source variant for other fields
      // This will be handled by passing the source variant separately
      
      return response.variant;
    }

    logger.warn('Invalid response when adding variant', { productId: id, response });
    return null;
  } catch (err) {
    logger.error('Failed to add variant to product', {
      productId,
      sku: variantData.sku,
      error: err.message,
      responseData: err.response?.data,
      stack: err.stack
    });
    return null;
  }
}

async function removeVariant(variantId) {
  if (!variantId) {
    logger.warn('Cannot remove variant: missing variantId');
    return false;
  }

  try {
    const id = variantId.includes('/') ? extractIdFromGid(variantId) : variantId;
    await shopifyRest('DELETE', `/variants/${id}.json`);
    logger.info('Variant removed successfully', { variantId: id });
    return true;
  } catch (err) {
    logger.error('Failed to remove variant', {
      variantId,
      error: err.message,
      responseData: err.response?.data,
      stack: err.stack
    });
    return false;
  }
}

async function addVariantMetafields(shopifyVariantId, variant) {
  if (!shopifyVariantId || !variant) {
    return;
  }

  try {
    // Convert to string first to check if it's a GID
    const variantIdStr = String(shopifyVariantId);
    const variantId = variantIdStr.includes('/') 
      ? extractIdFromGid(variantIdStr) 
      : variantIdStr;

    // Build all variant metafields
    const metafields = buildVariantMetafields(variant);
    
    // Create metafields in batches
    if (metafields.length > 0) {
        await createVariantMetafieldsInBatches(
          variantId,
          metafields,
          variant.sku || 'unknown',
          METAFIELD_BATCH_SIZE,
          METAFIELD_BATCH_DELAY_MS
        );
    }
  } catch (err) {
    logger.error('Error adding variant metafields', {
      shopify_variant_id: shopifyVariantId,
      sku: variant.sku,
      error: err.message,
      stack: err.stack
    });
  }
}

function isProductDiscontinued(productData, variants) {
  if (!variants || !Array.isArray(variants)) {
    return false;
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Check if any variant has a discontinued_date in the past
  for (const variant of variants) {
    if (!variant || typeof variant !== 'object') {
      continue;
    }

    if (variant.discontinued_date) {
      // "2099-12-31" seems to be a placeholder for active products
      if (variant.discontinued_date === '2099-12-31') {
        continue;
      }
      
      try {
        const discontinuedDate = new Date(variant.discontinued_date);
        if (isNaN(discontinuedDate.getTime())) {
          logger.debug('Invalid discontinued_date format', {
            date: variant.discontinued_date,
            sku: variant.sku
          });
          continue;
        }

        discontinuedDate.setHours(0, 0, 0, 0);
        
        // If discontinued_date is in the past, product is discontinued
        if (discontinuedDate < today) {
          return true;
        }
      } catch (err) {
        logger.debug('Error parsing discontinued_date', {
          date: variant.discontinued_date,
          sku: variant.sku,
          error: err.message
        });
      }
    }
  }
  
  return false;
}

async function archiveProduct(productId) {
  if (!productId) {
    logger.warn('Cannot archive product: missing productId');
    return false;
  }

  try {
    // REST API: DELETE /admin/api/{version}/products/{product_id}.json
    // This archives the product
    await shopifyRest('DELETE', `/products/${productId}.json`);
    logger.info('Product archived successfully', { productId });
    return true;
  } catch (err) {
    logger.error('Failed to archive product', {
      productId,
      error: err.message,
      responseData: err.response?.data,
      stack: err.stack
    });
    return false;
  }
}

function buildVariantData(variant, priceMap = null, productData = null) {
  if (!variant || typeof variant !== 'object') {
    return null;
  }

  try {
    // Get price from pricelist map, fallback to variant.price or 0.00
    let price = '0.00';
    if (priceMap && variant.sku) {
      const mappedPrice = priceMap.get(variant.sku);
      if (mappedPrice) {
        price = mappedPrice;
      } else if (variant.price) {
        price = variant.price.toString();
      }
    } else if (variant.price) {
      price = variant.price.toString();
    }

    // Validate price format
    const priceNum = parseFloat(price);
    if (isNaN(priceNum) || priceNum < 0) {
      logger.warn('Invalid price value, using 0.00', { sku: variant.sku, price });
      price = '0.00';
    }

    const variantData = {
      sku: variant.sku || '',
      price: price,
      inventory_management: 'shopify',
      inventory_policy: 'deny'
    };

    // Add gross_weight to variant weight field (Shopify native field)
    if (productData && productData.gross_weight) {
      try {
        const grossWeightValue = parseFloat(productData.gross_weight);
        if (!isNaN(grossWeightValue) && grossWeightValue >= 0) {
          variantData.weight = grossWeightValue.toString();
          // Add weight_unit if available (default to 'kg' if not specified)
          if (productData.gross_weight_unit) {
            variantData.weight_unit = productData.gross_weight_unit.toLowerCase();
          } else {
            variantData.weight_unit = 'kg'; // Default to kg
          }
        }
      } catch (err) {
        logger.debug('Failed to parse gross_weight for variant', {
          sku: variant.sku,
          gross_weight: productData.gross_weight,
          error: err.message
        });
      }
    }

    // Map GTIN to barcode (validate format)
    if (variant.gtin && typeof variant.gtin === 'string' && variant.gtin.trim()) {
      variantData.barcode = variant.gtin.trim();
    }

    // Add country_code_of_origin from product level (Shopify native field)
    // country_of_origin is at product level, not variant level
    if (productData && productData.country_of_origin && typeof productData.country_of_origin === 'string' && productData.country_of_origin.trim()) {
      variantData.country_code_of_origin = productData.country_of_origin.trim().toUpperCase();
    }

    // Add harmonized_system_code (HS code) from product level (Shopify native field)
    // commodity_code is at product level, not variant level
    if (productData && productData.commodity_code && typeof productData.commodity_code === 'string' && productData.commodity_code.trim()) {
      // Remove spaces from commodity_code (e.g., "9014 1000" -> "90141000")
      const hsCode = productData.commodity_code.trim().replace(/\s+/g, '');
      variantData.harmonized_system_code = hsCode;
    }

    // Add options if color exists
    const color = variant.color_description || variant.color_group;
    if (color && typeof color === 'string' && color.trim()) {
      variantData.option1 = color.trim();
    }

    return variantData;
  } catch (err) {
    logger.error('Error building variant data', {
      sku: variant?.sku,
      error: err.message
    });
    return null;
  }
}

async function createProductWithVariants(productData, variants, priceMap = null) {
  if (!productData || typeof productData !== 'object') {
    throw new Error('Invalid productData provided to createProductWithVariants');
  }

  if (!variants || !Array.isArray(variants) || variants.length === 0) {
    throw new Error('Invalid or empty variants array provided to createProductWithVariants');
  }

  // Build variants array for Shopify with validation
  const shopifyVariants = [];
  const variantIdMap = new Map(); // Map to store variant_id for each variant (by index)
  for (let i = 0; i < variants.length; i++) {
    const variant = variants[i];
    
    if (!variant || typeof variant !== 'object') {
      logger.warn('Skipping invalid variant', { index: i, master_code: productData.master_code });
      continue;
    }

    const variantData = buildVariantData(variant, priceMap, productData);
    if (variantData) {
      shopifyVariants.push(variantData);
      // Store variant_id if it exists for later metafield creation
      if (variant.variant_id) {
        variantIdMap.set(i, variant.variant_id);
      }
    }
  }

  if (shopifyVariants.length === 0) {
    throw new Error('No valid variants to create product');
  }

  // Extract product images (use first variant's images as product images) with validation
  const productImages = [];
  const nonImageAssets = []; // Collect non-image digital assets for metafield
  
  if (variants.length > 0 && variants[0] && variants[0].digital_assets && Array.isArray(variants[0].digital_assets)) {
    for (const asset of variants[0].digital_assets) {
      if (asset && asset.type === 'image') {
        const imageUrl = asset.url_highress || asset.url;
        if (imageUrl && typeof imageUrl === 'string' && imageUrl.trim()) {
          // Validate URL format
          try {
            new URL(imageUrl);
            productImages.push({ src: imageUrl.trim() });
          } catch (err) {
            logger.warn('Invalid image URL skipped', { url: imageUrl, master_code: productData.master_code });
          }
        }
      } else if (asset && asset.type !== 'image') {
        // Collect non-image assets (documents, etc.) with subtype
        const nonImageAsset = {
          url: asset.url || '',
          type: asset.type || '',
          subtype: asset.subtype || ''
        };
        if (nonImageAsset.url) {
          nonImageAssets.push(nonImageAsset);
        }
      }
    }
  }
  
  // Also collect non-image assets from other variants if they exist
  for (let i = 1; i < variants.length; i++) {
    const variant = variants[i];
    if (variant && variant.digital_assets && Array.isArray(variant.digital_assets)) {
      for (const asset of variant.digital_assets) {
        if (asset && asset.type !== 'image') {
          const nonImageAsset = {
            url: asset.url || '',
            type: asset.type || '',
            subtype: asset.subtype || ''
          };
          if (nonImageAsset.url && !nonImageAssets.some(existing => existing.url === nonImageAsset.url)) {
            nonImageAssets.push(nonImageAsset);
          }
        }
      }
    }
  }
  
  // Also check product-level digital_assets if they exist
  if (productData && productData.digital_assets && Array.isArray(productData.digital_assets)) {
    for (const asset of productData.digital_assets) {
      if (asset && asset.type !== 'image') {
        const nonImageAsset = {
          url: asset.url || '',
          type: asset.type || '',
          subtype: asset.subtype || ''
        };
        if (nonImageAsset.url && !nonImageAssets.some(existing => existing.url === nonImageAsset.url)) {
          nonImageAssets.push(nonImageAsset);
        }
      }
    }
  }

  // Determine if we need options (if variants have different colors)
  const hasColorVariants = variants.some(v => v.color_description || v.color_group);
  const options = hasColorVariants ? [{ name: 'Color' }] : [];

  // Build tags array - add master_code, product_name, category levels, and printable
  const tags = new Set(); // Use Set to avoid duplicates
  
  // Add master_code as tag if it exists
  if (productData.master_code) {
    tags.add(productData.master_code);
  }
  
  // Add product_name as tag if it exists
  if (productData.product_name) {
    tags.add(productData.product_name);
  }
  
  // Add printable as tag if it's "yes"
  if (productData.printable && productData.printable.toLowerCase() === 'yes') {
    tags.add('Printable');
  }
  
  // Collect all category levels from variants
  const categoryLevels = new Set();
  for (const variant of variants) {
    if (variant.category_level1) {
      categoryLevels.add(variant.category_level1);
    }
    if (variant.category_level2) {
      categoryLevels.add(variant.category_level2);
    }
    if (variant.category_level3) {
      categoryLevels.add(variant.category_level3);
    }
  }
  
  // Add all category levels to tags
  categoryLevels.forEach(category => tags.add(category));

  const payload = {
    product: {
      title: productData.short_description || productData.product_name || 'Untitled Product',
      body_html: productData.long_description || productData.short_description || '',
      vendor: productData.brand || 'midocean',
      product_type: productData.product_class || '',
      status: NEW_PRODUCT_STATUS, // Set product status (active, draft, archived)
      tags: Array.from(tags).join(', '), // Tags as comma-separated string
      options: options,
      variants: shopifyVariants,
      images: productImages.slice(0, MAX_PRODUCT_IMAGES) // Shopify limit
    }
  };

  let response;
  try {
    response = await shopifyRest('POST', '/products.json', payload);
  } catch (err) {
    logger.error('Failed to create product in Shopify', {
      master_code: productData.master_code,
      error: err.message,
      responseData: err.response?.data,
      stack: err.stack
    });
    throw err;
  }

  if (!response || !response.product) {
    logger.error('Invalid response from Shopify product creation', {
      master_code: productData.master_code,
      response: response
    });
    throw new Error('Invalid response from Shopify: missing product data');
  }

  const createdProduct = response.product;
  logger.info('Product created successfully', {
    master_code: productData.master_code,
    shopify_id: createdProduct.id,
    variant_count: shopifyVariants.length
  });

  // Add variant metafields and update customs info if they exist
  if (createdProduct.variants && Array.isArray(createdProduct.variants)) {
    for (let i = 0; i < createdProduct.variants.length && i < variants.length; i++) {
      const shopifyVariant = createdProduct.variants[i];
      const sourceVariant = variants[i];
      
      if (shopifyVariant && shopifyVariant.id && sourceVariant) {
        // Update customs information (country_code_of_origin and harmonized_system_code)
        // Pass inventory_item_id if available in the response to avoid extra API call
        const inventoryItemId = shopifyVariant.inventory_item_id || null;
        await updateVariantCustomsInfo(shopifyVariant.id, productData, inventoryItemId);
        
        // Add variant metafields
        await addVariantMetafields(shopifyVariant.id, sourceVariant);
      }
    }
  }

  // Add metafields if they exist (using batch processing)
  if (createdProduct.id) {
    const productId = createdProduct.id;
    
    // Build all metafields first
    const metafields = buildProductMetafields(productData, nonImageAssets);
    
    // Create metafields in batches with rate limit handling
    if (metafields.length > 0) {
      await createProductMetafieldsInBatches(
        productId,
        metafields,
        productData.master_code,
        METAFIELD_BATCH_SIZE,
        METAFIELD_BATCH_DELAY_MS
      );
    }
  }

  return createdProduct;
}

async function updateVariantPrice(variantId, price) {
  if (!variantId) {
    logger.warn('Cannot update variant price: missing variantId');
    return false;
  }

  if (!price || isNaN(parseFloat(price)) || parseFloat(price) < 0) {
    logger.warn('Cannot update variant price: invalid price value', { variantId, price });
    return false;
  }

  try {
    // Extract numeric ID from GID if needed
    const id = variantId.includes('/') ? extractIdFromGid(variantId) : variantId;
    
    if (!id) {
      logger.warn('Cannot update variant price: invalid variant ID format', { variantId });
      return false;
    }

    await shopifyRest('PUT', `/variants/${id}.json`, {
      variant: {
        id: id,
        price: price.toString()
      }
    });
    
    logger.debug('Variant price updated successfully', { variantId: id, price });
    return true;
  } catch (err) {
    logger.warn('Failed to update variant price', {
      variantId,
      price,
      error: err.message,
      responseData: err.response?.data
    });
    return false;
  }
}

async function updateVariantCustomsInfo(variantId, productData, inventoryItemId = null) {
  if (!variantId || !productData) {
    return false;
  }

  try {
    // Step 1: Extract numeric ID from GID if needed
    const id = variantId.toString().includes('/') ? extractIdFromGid(variantId.toString()) : variantId.toString();
    
    if (!id) {
      logger.warn('Cannot update variant customs info: invalid variant ID format', { variantId });
      return false;
    }

    let inventoryItemIdToUse = inventoryItemId;

    // If inventory_item_id not provided, get it from variant details
    if (!inventoryItemIdToUse) {
      try {
        // Get variant details to retrieve inventory_item_id
        const variantResponse = await shopifyRest('GET', `/variants/${id}.json`);
        if (!variantResponse || !variantResponse.variant || !variantResponse.variant.inventory_item_id) {
          logger.warn('Cannot update variant customs info: inventory_item_id not found', { 
            variantId: id,
            variantResponse: variantResponse 
          });
          return false;
        }
        inventoryItemIdToUse = variantResponse.variant.inventory_item_id;
      } catch (err) {
        // If GET fails, try again after a short delay (variant might not be fully created yet)
        if (err.response?.status === 400 || err.response?.status === 404) {
          logger.debug('Variant not immediately available, waiting before retry', { variantId: id });
          // Wait before retry
          await new Promise(resolve => setTimeout(resolve, VARIANT_RETRY_DELAY_MS));
          try {
            const variantResponse = await shopifyRest('GET', `/variants/${id}.json`);
            if (variantResponse && variantResponse.variant && variantResponse.variant.inventory_item_id) {
              inventoryItemIdToUse = variantResponse.variant.inventory_item_id;
            } else {
              logger.warn('Cannot update variant customs info: inventory_item_id not found after retry', { variantId: id });
              return false;
            }
          } catch (retryErr) {
            logger.warn('Failed to get variant details after retry', {
              variantId: id,
              error: retryErr.message,
              status: retryErr.response?.status
            });
            return false;
          }
        } else {
          throw err;
        }
      }
    }

    // Step 2: Prepare update data for InventoryItem according to Shopify API documentation
    // Reference: https://shopify.dev/docs/api/admin-rest/latest/resources/inventoryitem#put-inventory-items-inventory-item-id
    const inventoryItemData = {
      id: inventoryItemIdToUse
    };

    // Add country_code_of_origin if available (ISO 3166-1 alpha-2 format)
    if (productData.country_of_origin && typeof productData.country_of_origin === 'string' && productData.country_of_origin.trim()) {
      inventoryItemData.country_code_of_origin = productData.country_of_origin.trim().toUpperCase();
    }

    // Add harmonized_system_code if available (can be number or string)
    if (productData.commodity_code && typeof productData.commodity_code === 'string' && productData.commodity_code.trim()) {
      // Remove spaces from commodity_code (e.g., "9014 1000" -> "90141000")
      const hsCode = productData.commodity_code.trim().replace(/\s+/g, '');
      // Convert to number if it's a valid numeric string, otherwise keep as string
      const hsCodeNum = parseInt(hsCode, 10);
      inventoryItemData.harmonized_system_code = !isNaN(hsCodeNum) ? hsCodeNum : hsCode;
    }

    // Only update if we have at least one field to update (besides id)
    if (Object.keys(inventoryItemData).length > 1) {
      // Update InventoryItem with customs information
      // Payload structure: { inventory_item: { id, country_code_of_origin, harmonized_system_code } }
      const response = await shopifyRest('PUT', `/inventory_items/${inventoryItemIdToUse}.json`, {
        inventory_item: inventoryItemData
      });
      
      logger.info('Variant customs info updated successfully via InventoryItem', {
        variantId: id,
        inventoryItemId: inventoryItemIdToUse,
        country_code_of_origin: inventoryItemData.country_code_of_origin,
        harmonized_system_code: inventoryItemData.harmonized_system_code,
        response: response
      });
      return true;
    } else {
      logger.debug('No customs info to update', { variantId: id, inventoryItemId: inventoryItemId });
      return false;
    }
  } catch (err) {
    logger.error('Failed to update variant customs info', {
      variantId,
      error: err.message,
      status: err.response?.status,
      statusText: err.response?.statusText,
      responseData: err.response?.data,
      stack: err.stack
    });
    return false;
  }
}

async function syncVariantsForProduct(productId, sourceVariants, priceMap = null, productData = null) {
  if (!productId || !sourceVariants || !Array.isArray(sourceVariants)) {
    logger.warn('Invalid parameters for syncVariantsForProduct', { productId, sourceVariants });
    return { added: 0, removed: 0, updated: 0 };
  }

  const stats = { added: 0, removed: 0, updated: 0 };

  try {
    // Get full product with all existing variants
    const product = await getProductWithAllVariants(productId);
    if (!product || !product.variants) {
      logger.warn('Could not get product variants for sync', { productId });
      return stats;
    }

    // Build maps for comparison
    const existingVariantsMap = new Map();
    const sourceVariantsMap = new Map();

    // Map existing variants by SKU
    if (product.variants.edges && Array.isArray(product.variants.edges)) {
      for (const edge of product.variants.edges) {
        const variant = edge.node;
        if (variant && variant.sku) {
          existingVariantsMap.set(variant.sku, variant);
        }
      }
    }

    // Map source variants by SKU
    for (const variant of sourceVariants) {
      if (variant && variant.sku) {
        sourceVariantsMap.set(variant.sku, variant);
      }
    }

    // Find variants to add (exist in source but not in Shopify)
    for (const [sku, sourceVariant] of sourceVariantsMap) {
      if (!existingVariantsMap.has(sku)) {
        const variantData = buildVariantData(sourceVariant, priceMap, productData);
        if (variantData) {
          const added = await addVariantToProduct(productId, variantData);
          if (added && added.id) {
            // Update customs information (country_code_of_origin and harmonized_system_code)
            // Pass inventory_item_id if available in the response to avoid extra API call
            const inventoryItemId = added.inventory_item_id || null;
            await updateVariantCustomsInfo(added.id, productData, inventoryItemId);
            
            // Add variant metafields after variant is created
            await addVariantMetafields(added.id, sourceVariant);
            stats.added++;
            logger.info('Added new variant to product', { productId, sku });
          }
        }
      } else {
        // Variant exists - update price if pricelist is available
        const existingVariant = existingVariantsMap.get(sku);
        if (priceMap && existingVariant) {
          const newPrice = priceMap.get(sku);
          if (newPrice) {
            const priceUpdated = await updateVariantPrice(existingVariant.id, newPrice);
            if (priceUpdated) {
              stats.updated++;
              logger.debug('Updated variant price', { productId, sku, price: newPrice });
            }
          }
        }
      }
    }

    // Find variants to remove (exist in Shopify but not in source)
    for (const [sku, existingVariant] of existingVariantsMap) {
      if (!sourceVariantsMap.has(sku)) {
        const removed = await removeVariant(existingVariant.id);
        if (removed) {
          stats.removed++;
          logger.info('Removed variant from product', { productId, sku });
        }
      }
    }

    logger.info('Variant sync completed', { productId, ...stats });
    return stats;
  } catch (err) {
    logger.error('Error syncing variants for product', {
      productId,
      error: err.message,
      stack: err.stack
    });
    return stats;
  }
}

async function upsertProduct(productData, variants, priceMap = null) {
  // Check if product is discontinued
  const isDiscontinued = isProductDiscontinued(productData, variants);
  
  // Check if any variant SKU already exists
  for (const variant of variants) {
    if (variant.sku) {
      const existingProduct = await findProductBySku(variant.sku);
      if (existingProduct) {
        // Extract numeric ID from GID if needed
        const productId = existingProduct.id.includes('/') 
          ? extractIdFromGid(existingProduct.id) 
          : existingProduct.id;
        
        // If product is discontinued and not already archived, archive it
        if (isDiscontinued && existingProduct.status !== 'ARCHIVED') {
          logger.info('Product is discontinued, archiving...', { sku: variant.sku, productId });
          await archiveProduct(productId);
        } else if (!isDiscontinued && existingProduct.status === 'ARCHIVED') {
          logger.info('Product is no longer discontinued but is archived - unarchiving not implemented', { sku: variant.sku });
        }
        
        // Sync variants (add/remove/update)
        if (!isDiscontinued) {
          await syncVariantsForProduct(productId, variants, priceMap, productData);
        }
        
        logger.info('Product already exists, synced variants', { sku: variant.sku, productId });
        return existingProduct;
      }
    }
  }

  // If product is discontinued, don't create it
  if (isDiscontinued) {
    logger.info('Product is discontinued, skipping creation', { master_code: productData.master_code });
    return null;
  }

  // Create new product with variants
  logger.info('Creating new product with variants', { master_code: productData.master_code, variantCount: variants.length });
  const createdProduct = await createProductWithVariants(productData, variants, priceMap);
  return createdProduct;
}

module.exports = {
  upsertProduct
};
